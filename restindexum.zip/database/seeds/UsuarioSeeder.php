<?php

use Illuminate\Database\Seeder;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	DB::table('usuarios')->insert([
    		'name'		=> 'Abraham' ,
    		'lastname'	=> 'Aquino',
    		'address'	=> 'Calle Uno',
    		'email' 	=> 'kp@yopmail.com',
    		'password'	=> 'pass123',
    		]);
    	DB::table('usuarios')->insert([
    		'name'		=> 'Rosa' ,
    		'lastname'	=> 'Lopez',
    		'address'	=> 'Calle Dos',
    		'email' 	=> 'usuario2@gmail.com',
    		'password'	=> 'aaa123',
    		]);
    	DB::table('usuarios')->insert([
    		'name'		=> 'Ruben' ,
    		'lastname'	=> 'Gomez',
    		'address'	=> 'Calle Tres',
    		'email' 	=> 'usuario3@gmail.com',
    		'password'	=> 'bbb123',
    		]);
    }
}
