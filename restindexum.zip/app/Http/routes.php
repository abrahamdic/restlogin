<?php

use App\Usuario;

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
	return 'Hola Soy Abraham Aquino';
});

Route::post('api/login', 'ValidaLoginController@Acceso');

// Route::get('test', function(){

// 	$usuario = App\Usuario::where('email', 'kp@yopmail.com')->first();

// 	var_dump($usuario['attributes']);

// });